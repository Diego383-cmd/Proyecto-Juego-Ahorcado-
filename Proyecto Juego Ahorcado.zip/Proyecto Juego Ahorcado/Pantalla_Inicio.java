package actividad_1.Actividad_1.src;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pantalla_Inicio extends JFrame {
    
    public abstract class Juego {
        protected String palabraSecreta;
        protected int intentosRestantes;
    
        public Juego(String palabra, int intentos) {
            this.palabraSecreta = palabra;
            this.intentosRestantes = intentos;
        }
    
        public abstract boolean verificarLetra(char letra);
        public abstract boolean juegoTerminado();
    }

    public class Ahorcado extends Juego {
        private char[] progreso;
    
        public Ahorcado(String palabra, int intentos) {
            super(palabra, intentos);
            this.progreso = new char[palabra.length()];
            for (int i = 0; i < progreso.length; i++) {
                progreso[i] = '_';
            }
        }
    
        @Override
        public boolean verificarLetra(char letra) {
            boolean acertado = false;
            for (int i = 0; i < palabraSecreta.length(); i++) {
                if (palabraSecreta.charAt(i) == letra && progreso[i] == '_') {
                    progreso[i] = letra;
                    acertado = true;
                }
            }
            if (!acertado) {
                intentosRestantes--;
            }
            return acertado;
        }
    
        @Override
        public boolean juegoTerminado() {
            return intentosRestantes <= 0 || !new String(progreso).contains("_");
        }
    
        public String getProgreso() {
            return new String(progreso);
        }
    
        public int getIntentosRestantes() {
            return intentosRestantes;
        }
    }

    // Clase para manejar el juego con interfaz gráfica
    public Pantalla_Inicio() {
        // Configuración inicial de la ventana
        setTitle("Juego del Ahorcado");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // Panel para el progreso del juego
        JPanel panelProgreso = new JPanel();
        JLabel lblProgreso = new JLabel("Progreso: ");
        JLabel lblProgresoTexto = new JLabel("_ _ _ _");
        panelProgreso.add(lblProgreso);
        panelProgreso.add(lblProgresoTexto);

        // Panel para intentos restantes
        JPanel panelIntentos = new JPanel();
        JLabel lblIntentos = new JLabel("Intentos restantes: ");
        JLabel lblIntentosTexto = new JLabel("6");
        panelIntentos.add(lblIntentos);
        panelIntentos.add(lblIntentosTexto);

        // Panel para ingresar letras
        JPanel panelInput = new JPanel();
        JLabel lblLetra = new JLabel("Ingresa una letra:");
        JTextField txtLetra = new JTextField(1);
        JButton btnIntentar = new JButton("Intentar");
        panelInput.add(lblLetra);
        panelInput.add(txtLetra);
        panelInput.add(btnIntentar);

        // Agregar los paneles a la ventana
        add(panelProgreso, BorderLayout.NORTH);
        add(panelIntentos, BorderLayout.CENTER);
        add(panelInput, BorderLayout.SOUTH);

        // Crear el juego
        Ahorcado juego = new Ahorcado("java", 6);

        // Acción del botón Intentar
        btnIntentar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String letra = txtLetra.getText();
                if (letra.length() == 1) {
                    juego.verificarLetra(letra.charAt(0));
                    lblProgresoTexto.setText(juego.getProgreso());
                    lblIntentosTexto.setText(String.valueOf(juego.getIntentosRestantes()));

                    if (juego.juegoTerminado()) {
                        String mensaje = juego.getProgreso().contains("_") ?
                                "¡Perdiste! La palabra era: " + juego.palabraSecreta :
                                "¡Ganaste!";
                        JOptionPane.showMessageDialog(null, mensaje);
                        btnIntentar.setEnabled(false);
                        txtLetra.setEnabled(false);
                    }
                }
                txtLetra.setText("");
            }
        });
    }

    // Método principal
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Pantalla_Inicio().setVisible(true);
        });
    }
}

